This image was taken from google, and is being used for non-profit purposes, 
credits to its respective author.